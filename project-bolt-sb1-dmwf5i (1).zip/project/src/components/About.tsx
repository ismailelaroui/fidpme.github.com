import React from 'react';
import { History, Target, Award, Users } from 'lucide-react';

const values = [
  {
    icon: <Award className="h-8 w-8 text-blue-600" />,
    title: "Professionnalisme",
    description: "Une expertise reconnue et des services de haute qualité"
  },
  {
    icon: <Users className="h-8 w-8 text-blue-600" />,
    title: "Proximité",
    description: "Un accompagnement personnalisé et une écoute attentive"
  },
  {
    icon: <Target className="h-8 w-8 text-blue-600" />,
    title: "Engagement",
    description: "Un suivi rigoureux et des solutions adaptées"
  }
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
                alt="Bureau FID-PME"
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white p-6 rounded-lg shadow-lg">
                <div className="text-4xl font-bold">20+</div>
                <div className="text-sm">années d'expérience</div>
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Notre Histoire</h2>
            <div className="space-y-6 text-gray-600">
              <p>
                Fondé en 2004 à Rabat, FID-PME est un cabinet fiduciaire et de consultation juridique spécialisé dans l'accompagnement des entreprises et des particuliers. En 2010, nous avons déménagé à Témara pour être plus proche de notre clientèle et offrir un service personnalisé de proximité.
              </p>
              <p>
                Avec plus de 20 ans d'expérience, nous nous engageons à fournir des services de haute qualité en matière de comptabilité, de gestion fiscale, et de conseil juridique. Notre expertise est au service des PME, des indépendants, et des particuliers.
              </p>
              <div className="border-l-4 border-blue-600 pl-4 my-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Notre Mission</h3>
                <p className="text-gray-600">
                  Offrir un service fiable et transparent pour soutenir la croissance et la stabilité financière de nos clients.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-20">
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">Nos Valeurs</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center p-6 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors duration-300">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                  {value.icon}
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">{value.title}</h4>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-20 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Notre Vision</h3>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Être un acteur de référence dans le domaine fiduciaire et juridique à Témara et au-delà, en accompagnant nos clients dans chaque étape de leur développement.
          </p>
        </div>
      </div>
    </section>
  );
}