import React from 'react';
import { ArrowRight, Shield, Scale, Calculator } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 pt-32 pb-20">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')] mix-blend-overlay opacity-20"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Votre Partenaire de Confiance en
            <span className="block text-blue-200">Gestion d'Entreprise</span>
          </h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            FID-PME vous accompagne dans la gestion comptable, juridique et fiscale de votre entreprise à Témara et ses environs.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="#contact" className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-blue-50">
              Prendre Rendez-vous
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
            <a href="#services" className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-blue-700">
              Nos Services
            </a>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white/10 backdrop-blur-lg p-6 rounded-lg">
            <Shield className="h-12 w-12 text-blue-200 mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Fiduciaire</h3>
            <p className="text-blue-100">Gestion comptable professionnelle et suivi personnalisé de vos comptes.</p>
          </div>
          <div className="bg-white/10 backdrop-blur-lg p-6 rounded-lg">
            <Scale className="h-12 w-12 text-blue-200 mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Conseil Juridique</h3>
            <p className="text-blue-100">Expertise en droit des affaires et accompagnement juridique complet.</p>
          </div>
          <div className="bg-white/10 backdrop-blur-lg p-6 rounded-lg">
            <Calculator className="h-12 w-12 text-blue-200 mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Gestion Fiscale</h3>
            <p className="text-blue-100">Optimisation fiscale et conformité avec la réglementation en vigueur.</p>
          </div>
        </div>
      </div>
    </div>
  );
}