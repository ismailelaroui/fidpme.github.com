import React from 'react';
import { 
  Calculator, 
  FileText, 
  Users, 
  Building2, 
  ClipboardCheck, 
  BookOpen,
  Scale,
  FileSearch,
  Receipt,
  UserCheck,
  TrendingUp,
  FileSpreadsheet
} from 'lucide-react';

const services = [
  {
    icon: <BookOpen className="h-8 w-8 text-blue-600" />,
    title: "Comptabilité",
    description: "Gestion comptable complète pour entreprises et particuliers",
    features: [
      "Tenue de la comptabilité",
      "Préparation des comptes annuels",
      "Gestion des écritures comptables",
      "Établissement des livres comptables"
    ]
  },
  {
    icon: <Calculator className="h-8 w-8 text-blue-600" />,
    title: "Gestion Fiscale",
    description: "Optimisation et conformité fiscale pour votre entreprise",
    features: [
      "Déclarations fiscales (TVA, IS, IR)",
      "Optimisation fiscale légale",
      "Conseil en fiscalité",
      "Assistance contrôle fiscal"
    ]
  },
  {
    icon: <Users className="h-8 w-8 text-blue-600" />,
    title: "Gestion de la Paie & RH",
    description: "Solutions complètes pour la gestion des ressources humaines",
    features: [
      "Bulletins de paie",
      "Déclarations sociales",
      "Suivi des cotisations",
      "Conseil droit du travail"
    ]
  },
  {
    icon: <TrendingUp className="h-8 w-8 text-blue-600" />,
    title: "Conseil en Gestion",
    description: "Accompagnement stratégique pour votre développement",
    features: [
      "Création d'entreprise",
      "Budgets prévisionnels",
      "Suivi de trésorerie",
      "Conseil stratégique"
    ]
  },
  {
    icon: <FileSearch className="h-8 w-8 text-blue-600" />,
    title: "Audit et Contrôle",
    description: "Évaluation approfondie de votre situation financière",
    features: [
      "Audits comptables",
      "Audit de gestion",
      "Contrôle financier",
      "Gestion des risques"
    ]
  },
  {
    icon: <FileText className="h-8 w-8 text-blue-600" />,
    title: "Secrétariat Juridique",
    description: "Gestion administrative et juridique complète",
    features: [
      "Procès-verbaux",
      "Registres légaux",
      "Formalités administratives",
      "Conseil juridique"
    ]
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Nos Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Une expertise complète en gestion d'entreprise, comptabilité et conseil juridique pour accompagner votre réussite
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 group overflow-hidden"
            >
              <div className="p-8">
                <div className="w-16 h-16 bg-blue-50 rounded-lg flex items-center justify-center mb-6 group-hover:bg-blue-100 transition-colors duration-300">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">
                  {service.title}
                </h3>
                <p className="text-gray-600 mb-6">
                  {service.description}
                </p>
                <ul className="space-y-3">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-700">
                      <ClipboardCheck className="h-5 w-5 text-blue-600 mr-3" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <a 
            href="#contact" 
            className="inline-flex items-center px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-300"
          >
            Demander un Devis
            <Scale className="ml-2 h-5 w-5" />
          </a>
        </div>
      </div>
    </section>
  );
}